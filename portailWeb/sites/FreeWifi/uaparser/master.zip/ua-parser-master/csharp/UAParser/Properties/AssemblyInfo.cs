﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("UAParser")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("UAParser")]
[assembly: AssemblyCopyright("Copyright ©  2012")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("f5d74137-db23-4674-afe7-6635440f9b38")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

[assembly:InternalsVisibleTo("UAParser.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100a7c49ce2884f71f640072402131fc866e654c982958f605a1ea0162b512138a87eab09c3335835f6d56231732f609fb9c48b03af24c9cce40cdcc1ac08ff8821cf3413a319770520f9c019d3ed6a185d60b673271c1f2fb380951c37290c99fbd4cd3a3db70bd48d524cf91ce9323e6b3c02765a2790e23a0419c05751b00498")]
